import re
import numpy as np
import pandas as pd
    
def clean_merged_df(merged_df: pd.DataFrame) -> pd.DataFrame:

    # 函数1：计算年薪
    def extract_salary_midpoint(s):
        s = str(s)
        nums = re.findall(r"\d{1,3}(?:,\d{3})*|\d+", s)
        nums = [int(n.replace(",", "")) for n in nums]
        if not nums:
            return np.nan
        if len(nums) == 2:
            return (nums[0] + nums[1]) // 2
        return nums[0]

    # 函数2：计算每周工作小时数
    def working_hours_per_week(s: str, hours_per_day: float = 8) -> float:
        s = str(s).lower().strip()
        if "full-time" in s:
            return 5 * hours_per_day
        match = re.search(r"(\d+)(?:\s*and\s*(1/2))?\s*days?", s)
        if "part-time" in s and match:
            days = int(match.group(1))
            if match.group(2):
                days += 0.5
            return days * hours_per_day
        match = re.search(r"(\d+(\.\d+)?)\s*hours?", s)
        if match:
            return float(match.group(1))
        return np.nan

    # 函数3：拆分weight change
    def process_weight_column(s: str) -> float:
        val_str = str(s).lower().strip()
        nums = re.findall(r'(\d+(\.\d+)?)', val_str)
        if nums:
            nums = [float(x[0]) for x in nums]
            if len(nums) > 1:
                num = (min(nums) + max(nums)) / 2
            else:
                num = nums[0]
        else:
            num = np.nan
        if 'lost' in val_str or 'loss' in val_str:
            cat = "lost"
            value = -num if not np.isnan(num) else np.nan
        elif 'gain' in val_str or 'gained' in val_str:
            cat = "gained"
            value = num
        else:
            cat = "no change"
            value = 0.0
        return pd.Series([cat, value])

    # 函数4: ethnicity
    def classify_ethnicity(value: str):
        v = str(value).lower()
        if "white" in v:
            return "White"
        elif "mixed" in v:
            return "Mixed / Multiple"
        elif "asian" in v or "chinese" in v:
            return "Asian"
        elif "black" in v:
            return "Black / African / Caribbean"
        elif "other" in v:
            return "Other"
        else:
            return "Unknown"

    # 函数5：拆分职业与年限
    profession_keywords = {
        "nursing": "Employee of a private for-profit company or business, or of an individual, for wages, salary, or commissions",
        "incubator manager": "Employee of a private for-profit company or business, or of an individual, for wages, salary, or commissions",
        "biochemist": "Employee of a private not-for-profit, tax-exempt, or charitable organization",
        "carer": "Self-employed in own not incorporated business, professional practice, or farm",
        "kitchen designer": "Self-employed in own not incorporated business, professional practice, or farm",
        "business": "Employee of a private for-profit company or business, or of an individual, for wages, salary, or commissions",
        "banker": "Employee of a private for-profit company or business, or of an individual, for wages, salary, or commissions",
        "operation theatre hca": "Working without pay in family business or farm",
        "customer service": "Employee of a private for-profit company or business, or of an individual, for wages, salary, or commissions",
        "civil servant": "Local government employee (city, county, etc.)",
        "book-keeper": "Employee of a private for-profit company or business, or of an individual, for wages, salary, or commissions",
        "administration": "Local government employee (city, county, etc.)",
        "senior acct manager": "Employee of a private for-profit company or business, or of an individual, for wages, salary, or commissions",
        "executive assistant": "Employee of a private for-profit company or business, or of an individual, for wages, salary, or commissions",
        "family content supervisor": "Employee of a private not-for-profit, tax-exempt, or charitable organization"
    }

    cow_categories = list(set(profession_keywords.values()))
    cow_categories += ["Unemployed and last worked 5 years ago or earlier or never worked",
                       "N/A (less than 16 years old/NILF who last worked more than 5 years ago or never worked)"]

    def process_profession_data(df: pd.DataFrame) -> pd.DataFrame:
        profession_cols = [
            'If you answered working, please fill in: current profession and years working',
            'If you answered not working, please fill last profession and years working',
            'If you answered retired, please fill in, last profession and years working'
        ]

        def get_status_cow_years(row):
            status = "NaN"
            raw = None
            is_not_working = False
            for col, st in zip(profession_cols, ["working", "not working", "retired"]):
                val = row.get(col)
                if pd.notna(val) and str(val).strip():
                    raw = str(val)
                    status = st
                    break
            if raw is None:
                return pd.Series([status,
                                  "N/A (less than 16 years old/NILF who last worked more than 5 years ago or never worked)",
                                  np.nan])
            if ',' in raw:
                profession_part, years_part = raw.split(',', 1)
            else:
                profession_part, years_part = raw, ''
            profession_lower = profession_part.strip().lower()
            years_part_lower = years_part.lower()
            num_matches = re.findall(r'(\d+(?:\.\d+)?)', years_part_lower)
            total_years = float(num_matches[0]) if num_matches else np.nan
            if len(num_matches) > 1 and 'month' in years_part_lower:
                total_years += float(num_matches[1]) / 12
            cow_class = "N/A (less than 16 years old/NILF who last worked more than 5 years ago or never worked)"
            for key, cls in profession_keywords.items():
                if key in profession_lower:
                    cow_class = cls
                    break
            if status == "not working" and (np.isnan(total_years) or total_years >= 5):
                cow_class = "Unemployed and last worked 5 years ago or earlier or never worked"
                total_years = -total_years if not np.isnan(total_years) else 0
            return pd.Series([status, cow_class, total_years])

        df[['Status of worker', 'Class of worker', 'Decades of working']] = df.apply(get_status_cow_years, axis=1)
        df['Class of worker'] = pd.Categorical(df['Class of worker'], categories=cow_categories)
        return df.drop(columns=[c for c in profession_cols if c in df.columns], errors='ignore')

    # 函数6：睡觉
    def parse_sleep_hours(value: str):
        if pd.isna(value):
            return np.nan
        text = str(value).lower().replace("hous", "hours")
        numbers = re.findall(r'\d+(?:\.\d+)?', text)
        return np.mean([float(n) for n in numbers]) if numbers else np.nan

    # 处理列
    merged_df["Salary (annual net salary)"] = merged_df["Salary (annual net salary)"].astype(str).apply(extract_salary_midpoint)
    merged_df["Hours worked per week"] = merged_df[["Working time", "If you answered shift worker, please describe your shifts patterns"]].fillna('').agg(lambda x: ' '.join(filter(None, x)), axis=1).apply(working_hours_per_week)
    merged_df[["Have you lost or gained weight in the past 3 months?", "Have you lost or gained weight in the past 3 months? If yes, how much?"]] = merged_df['Have you lost or gained weight in the past 3 months? If yes, how much?'].apply(process_weight_column)
    merged_df['Ethnicity'] = merged_df['Ethnicity'].apply(classify_ethnicity)
    merged_df["Ethnicity_Is White or Not"] = merged_df["Ethnicity"].apply(lambda x: 'white' if x == 'White' else 'non-white')
    merged_df = process_profession_data(merged_df)
    merged_df["How many hours per day do you sleep during workdays?"] = merged_df["How many hours per day do you sleep during workdays?"].apply(parse_sleep_hours)
    merged_df["How many hours per day do you sleep during free days?"] = merged_df["How many hours per day do you sleep during free days?"].apply(parse_sleep_hours)

    # 确保 Place of Residence 为字符串再拆分
    merged_df['Place of Residence'] = merged_df['Place of Residence'].astype(str)
    merged_df[['City of Residence', 'Country of Residence']] = merged_df['Place of Residence'].str.split(',', n=1, expand=True)
    merged_df['City of Residence'] = merged_df['City of Residence'].astype(str).str.strip()
    merged_df['Country of Residence'] = merged_df['Country of Residence'].astype(str).str.strip()

    # Weight / Height 列转换
    merged_df['Weight (kg)'] = merged_df['Weight (kg)'].astype(str).str.replace(',', '.').replace('nan', np.nan).astype(float)
    merged_df['Height (cm)'] = merged_df['Height (cm)'].astype(str).str.replace(',', '.').replace('nan', np.nan).astype(float)

    return merged_df


def clean_and_compare_columns(df1: pd.DataFrame, df2: pd.DataFrame) -> tuple:
    """
    清理 df1 的列名（替换特殊字符、去掉重复后缀），并比较 df1 与 df2 列差异。

    参数:
        df1 : pd.DataFrame
            待清理的 DataFrame
        df2 : pd.DataFrame
            用于对比列差异的 DataFrame

    返回:
        tuple:
            df1_cleaned : pd.DataFrame
                清理后的 df1
            only_in_df1 : set
                仅存在 df1 的列名
            only_in_df2 : set
                仅存在 df2 的列名
    """
    df1.columns = (
        df1.columns
        .str.replace(' ? 90 mg/dL (5.0 mmol/L)', ' ≥ 90 mg/dL (5.0 mmol/L)', regex=False)
        .str.replace(' ? 100 mg/dL (1.7 mmol/L))', ' ≥ 100 mg/dL (1.7 mmol/L))', regex=False)
        .str.replace('BP ? 130 or diastolic BP ? 85 mm Hg.', 'BP ≥ 130 or diastolic BP ≥ 85 mm Hg.', regex=False)
    )

    for col in df1.columns.tolist():  # 用列表防止修改列时报错
        if col.startswith("CoDiet") or any(col.endswith(suffix) for suffix in ['_1','_2','_3','_4','.1','.2','.3','.4']):
            new_col = col.replace("CoDiet ", "", 1)
            for suffix in ['_1','_2','_3','_4','.1','.2','.3','.4']:
                new_col = new_col.rstrip(suffix)
            if new_col in df1.columns:
                df1.drop(columns=[col], inplace=True)
            else:
                df1.rename(columns={col: new_col}, inplace=True)

    cols1 = set(df1.columns.str.strip())
    cols2 = set(df2.columns.str.strip())
    only_in_df1 = cols1 - cols2
    only_in_df2 = cols2 - cols1

    print(f"仅存在 df1 的列: {only_in_df1}")
    print(f"仅存在 df2 的列: {only_in_df2}")
    print(f"数量 -> df1: {len(only_in_df1)}, df2: {len(only_in_df2)}")

    return df1, only_in_df1, only_in_df2


# --------------------------
# 读取映射and验证（假设 abbr 已经存在）
# --------------------------
def check_csv_vs_codedic(df_csv: pd.DataFrame, codedic: pd.DataFrame):
    """
    双向检查 CSV 列名和 code dictionary 列名，并检查 abbr 是否重复。

    参数:
        df_csv: 待检查的 CSV 数据 DataFrame
        codedic: code dictionary DataFrame，必须包含 'column_name' 和 'abbr' 列

    输出:
        打印检查结果
    """

    # 1️⃣ data 中存在，但 code dictionary 中缺失
    missing_in_codedic = [col for col in df_csv.columns if col not in codedic['column_name'].values]

    # 2️⃣ code dictionary 中存在，但 data 中缺失
    missing_in_data = [col for col in codedic['column_name'].values if col not in df_csv.columns]

    print("\n=== 检查结果 ===")
    if missing_in_codedic:
        print("⚠️ data 中存在，但 code dictionary 中缺失的 column_name:")
        print(missing_in_codedic)
    else:
        print("✅ data 中所有列名都在 code dictionary 中。")

    if missing_in_data:
        print("\n⚠️ code dictionary 中存在，但 data 中缺失的 column_name:")
        print(missing_in_data)
    else:
        print("✅ code dictionary 中所有列名都在 data 中。")

    # 3️⃣ 检查 abbr 是否重复
    duplicated_abbr = codedic[codedic['abbr'].duplicated(keep=False)]
    if not duplicated_abbr.empty:
        print("\n⚠️ 重复的 abbr:")
        print(duplicated_abbr[['abbr', 'column_name']])
    else:
        print("\n✅ 没有重复的 abbr。")

def dynamic_bin_numeric(series, max_bins=5):
    series = pd.to_numeric(series, errors='coerce').dropna()
    if series.empty:
        return []
    unique_vals = np.unique(series)
    if len(unique_vals) <= max_bins:
        return [(round(v, 2), round(v, 2)) for v in sorted(unique_vals)]
    try:
        bins = np.quantile(series, q=np.linspace(0, 1, max_bins+1))
        bins = np.unique(bins)
        if len(bins) <= 1:
            return [(round(v, 2), round(v, 2)) for v in sorted(unique_vals)]
        bin_limits = [(round(bins[i], 2), round(bins[i+1], 2)) for i in range(len(bins)-1)]
        return bin_limits
    except Exception:
        return [(round(v, 2), round(v, 2)) for v in sorted(unique_vals)]

def add_categorical(col_data, st_name, col, data_dict, start_code=0):
    # Explicitly convert to string before using .str
    categories = pd.Series(col_data).dropna().astype(str).str.lower().unique()

    cat_dict = {cat:i for i, cat in enumerate(categories, start=start_code)}
    l = 0  # Initialize l here
    for cat, code in cat_dict.items():
        if 'SERIALNO' == st_name or 'patient' == st_name or 'visit' == st_name:
            l = len(str(cat).replace("_", ""))
            st = st_name
            data_dict.append({
                "VAL":"VAL",
                "ST":f"{st}",
                "Len": l,
                "Type":"C",
                "Min": cat,
                "Max": cat,
                "Description": f"{col}_{cat}"
            })

        else:
            st = st_name
            l = len(str(code))
            data_dict.append({
                "VAL":"VAL",
                "ST":f"{st}",
                "Len": l,
                "Type":"C",
                "Min": code,
                "Max": code,
                "Description": f"{col}_{cat}"
            })
        # 字段行
        if len(cat_dict) > 0:
            l = max(len(str(code)) for code in cat_dict.values())
        else:
            l = 0

    data_dict.append({
        "VAL":"NAME",
        "ST": f"{st_name}",
        "Len": l,
        "Type":"C",
        "Min": '',
        "Max": '',
        "Description": f"{col}"
    })
    return data_dict, cat_dict

def generate_data_dictionary(df: pd.DataFrame, abbr: pd.DataFrame, max_bins: int = 5, output_file: str = None):
    """
    根据 DataFrame 自动生成数据字典。

    参数：
    df : pd.DataFrame
        待处理数据。
    abbr : pd.DataFrame
        code dictionary, 必须包含 'column_name' 和 'type' 列。
    mapping : dict
        列名映射到 ST 名称，可选。
    max_bins : int
        数值列的最大分箱数，默认 5。
    output_file : str
        输出 CSV 文件路径，如果提供则保存为 CSV。

    返回：
    data_dict : pd.DataFrame
        生成的数据字典。
    """
    mapping = dict(zip(abbr['column_name'], abbr['abbr']))
    data_dict = []

    for col in df.columns:
        st_name = mapping[col] if col in mapping else col
        col_data = df[col].dropna()

        type_info = abbr.loc[abbr['column_name'] == col, 'type']
        is_num_in_abbr = not type_info.empty and type_info.values[0] == 'N'

        col_numeric = pd.to_numeric(col_data, errors='coerce')
        is_numeric_data = col_numeric.notna().sum() > 0 and col_numeric.notna().sum() >= len(col_data) * 0.8

        # Prioritize type from abbr if available, otherwise infer from data
        if is_num_in_abbr or (not is_num_in_abbr and is_numeric_data):
            # 数值列
            bins = dynamic_bin_numeric(col_numeric, max_bins=max_bins)
            if bins: # Only add if bins are generated
                for b_min, b_max in bins:
                    data_dict.append({
                        "VAL": "VAL",
                        "ST": f"{st_name}",
                        "Len": len(str(b_max)),
                        "Type": "N",
                        "Min": b_min,
                        "Max": b_max,
                        "Description": f"{col}_{b_min}_{b_max}"
                    })
                # 字段行
                data_dict.append({
                    "VAL": "NAME",
                    "ST": f"{st_name}",
                    "Len": len(str(b_max)),
                    "Type": "N",
                    "Min": '',
                    "Max": '',
                    "Description": f"{col}"
                })
            else: # If no bins, treat as categorical (e.g., all NaNs or non-numeric)
                 data_dict = add_categorical(col_data, st_name, col, data_dict)
        else:
            # 字符列
            data_dict, cat_dict = add_categorical(col_data, st_name, col, data_dict)
            if col != 'User ID':# and 'patient' != col and 'visit' != col:
                #if st_name == 'ILL':
                #print(df[col], cat_dict)
                df[col] = df[col].str.lower().map(cat_dict)
                #.map(lambda x: cat_dict.get(str(x).strip().lower().replace(" ", ""), x))
                #.replace(cat_dict)#.map(cat_dict)

    mapping_existing = {k: v for k, v in mapping.items() if k in df.columns}
    df_renamed = df.rename(columns=mapping_existing)
    data_dict = pd.DataFrame(data_dict)

    if output_file:
        data_dict.to_csv(output_file, index=False, encoding="utf-8-sig", sep=';')

    return df_renamed,data_dict


# ================================================================
# 2️⃣ 主清洗函数
# ================================================================

def clean_data(
    sociodemographics_data: pd.DataFrame,
    exdbn_data: pd.DataFrame,
    abbreviation_data: pd.DataFrame,
    max_bins: int = 5
):
    """主清洗函数：合并、清洗并生成数据字典。"""
    sociodemographics = sociodemographics_data.rename(columns={'volunteer_id': 'Volunteer ID'})
    sociodemographics['Volunteer ID'] = sociodemographics['Volunteer ID'].astype(str).str.strip()
    exdbn_data['patient'] = exdbn_data['patient'].astype(str).str.strip()

    merged_df = pd.merge(exdbn_data, sociodemographics, left_on='patient', right_on='Volunteer ID', how='inner')
    merged_df.columns = (
        merged_df.columns.str.strip()
        .str.replace("\xa0", "", regex=False)
        .str.replace("\n", "", regex=False)
    )

    merged_df_cleaned = clean_merged_df(merged_df)
    abbreviation_data.columns = abbreviation_data.columns.str.strip()

    from io import StringIO  # 避免未定义变量错误
    acs_data, data_dict = generate_data_dictionary(
        merged_df_cleaned,
        abbreviation_data,
        max_bins=max_bins
    )

    # 删除缺失太多的列并清除NaN行
    na_count = acs_data.isna().sum()
    acs_data = acs_data.drop(columns=na_count[na_count > 5].index).dropna()
    if 'SERIALNO' in acs_data.columns:
        acs_data = acs_data.drop('SERIALNO', axis=1)

    print(f"✅ Cleaned dataset shape: {acs_data.shape}")
    return acs_data, data_dict

