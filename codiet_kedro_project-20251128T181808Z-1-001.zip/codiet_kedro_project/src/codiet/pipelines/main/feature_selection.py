import torch
import numpy as np
import pandas as pd
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from sklearn.linear_model import Lasso
import seaborn as sns
import matplotlib.pyplot as plt


def load_data(data='codiet', target_feature='WGTCN', seed=0):
    """
    Load dataset and return numeric feature matrix X, target y, and feature names.
    Supported datasets: 'codiet', 'simulated_observational_data', 'lalonde'
    """
    np.random.seed(seed)

    if data == 'simulated_observational_data':
        from experiments.generate_data import generate_data
        df = generate_data(
            N=1000,
            n_features=3,
            beta=[0, -2, 3, -5],
            error_std=0.1,
            tau=[1, -5, -5, 10],
            tau_std=0.1,
            discrete_outcome=True,
            seed=seed,
            feature_effect=0,
            propensity_coef=[0, -1, 1, -1],
            index_name='index'
        )

    elif data == 'lalonde':
        def get_lalonde():
            cols = ['treat', 'age', 'educ', 'black', 'hisp', 'married', 'nodegr','re74','re75','re78']
            control_df = pd.read_csv('http://www.nber.org/~rdehejia/data/nswre74_control.txt', sep='\s+', header=None, names=cols)
            treated_df = pd.read_csv('http://www.nber.org/~rdehejia/data/nswre74_treated.txt', sep='\s+', header=None, names=cols)
            lalonde_df = pd.concat([control_df, treated_df], ignore_index=True)
            lalonde_df['u74'] = np.where(lalonde_df['re74'] == 0, 1.0, 0.0)
            lalonde_df['u75'] = np.where(lalonde_df['re75'] == 0, 1.0, 0.0)
            return lalonde_df

        lalonde_df = get_lalonde()
        df = lalonde_df.copy()
        df.rename(columns={'treat': 'Treatment', 're78': 'Outcome'}, inplace=True)
        df['Outcome'] = np.where(df['Outcome'] > 0, 1.0, 0.0)
        df.loc[:, 'age'] = df['age'].apply(lambda x: '{:.0f}'.format(x)[:-1] + '0s')
        df = pd.get_dummies(df, columns=['age'], drop_first=True)
        cols = ['nodegr', 'black', 'hisp', 'age_20s', 'age_30s', 'age_40s', 'age_50s',
                'educ', 'married', 'u74', 'u75', 'Treatment', 'Outcome']
        df = df[cols]

    elif data == 'codiet':
        Codiet_url = "https://raw.githubusercontent.com/sereneHe/my-data/refs/heads/main/codiet_data.csv"
        df = pd.read_csv(Codiet_url, engine='python',sep=';', on_bad_lines='skip')

    else:
        raise ValueError(f"Unsupported dataset: {data}")

    # --- Handle missing target feature gracefully ---
    if target_feature not in df.columns:
        print(f"⚠️ Warning: Target feature '{target_feature}' not found in dataset columns. Skipping this feature.")
        return None, None, df.columns.tolist()

    # --- Prepare X and y ---
    y = df[target_feature].to_numpy().astype(float)
    X = df.drop(columns=[target_feature])

    # Drop non-numeric columns
    non_numeric_cols = X.select_dtypes(exclude=np.number).columns.tolist()
    if non_numeric_cols:
        X = X.drop(columns=non_numeric_cols)

    feature_names = X.columns
    X = X.to_numpy()

    print(f"✅ Loaded '{data}' dataset. Target: {target_feature}, X shape: {X.shape}, y shape: {y.shape}")
    return X, y, feature_names


def significance_marker(val):
    abs_val = abs(val)
    if abs_val < 0.001:
        return '***'
    elif abs_val < 0.01:
        return '**'
    else:
        return ''

def analyze_linear_significance(X, feature_names, pho=0.1, input_features=None, out_features=None, seed=0):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if isinstance(X, np.ndarray):
        X_tensor = torch.tensor(X, dtype=torch.float32)
    else:
        X_tensor = X.float()
    if input_features is None:
        input_features = X_tensor.shape[-1]
    if out_features is None:
        out_features = 1
    model_linear = nn.Linear(in_features=input_features, out_features=out_features)
    with torch.no_grad():
        output = model_linear(X_tensor)
    weights = model_linear.weight.data.numpy()
    contributions = np.abs(X[:, None, :] * weights[None, :, :])
    mean_contributions = contributions.mean(axis=0)
    feature_counts = np.sum(mean_contributions > pho, axis=0)
    feature_count_df = pd.DataFrame({
        'Sig_Count_linear': feature_counts,
        'Sig_Rate_linear': feature_counts / out_features
    }, index=feature_names).sort_values('Sig_Count_linear', ascending=False)
    linear_features_set = [feature_names[i] for i, count in enumerate(feature_counts) if count > 0]

    return feature_count_df, linear_features_set, mean_contributions


class SimpleNet(nn.Module):
    def __init__(self, input_dim, num_classes):
        super(SimpleNet, self).__init__()
        self.fc1 = nn.Linear(input_dim, 16)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(16, 16)
        self.relu = nn.ReLU()
        self.fc3 = nn.Linear(16, num_classes)
    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        x = self.relu(x) # Added missing ReLU
        x = self.fc3(x)
        return x

def analyze_nonlinear_significance(X, y, feature_names, num_classes, batch_size=8, epochs=30, lr=1e-3, seed=0):
    torch.manual_seed(seed)
    np.random.seed(seed)
    X_tensor = torch.tensor(X, dtype=torch.float32)
    y_tensor = torch.tensor(y, dtype=torch.long) # Ensure target is LongTensor for cross_entropy

    model = SimpleNet(X.shape[-1], num_classes)
    optimizer = Adam(model.parameters(), lr=lr)
    dataloader = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(X_tensor, y_tensor),
        batch_size=batch_size,
        shuffle=True
    )
    print("Starting training...")
    for epoch in range(epochs):
        model.train()
        avg_epoch_loss = []
        for feature, label in dataloader:
            optimizer.zero_grad()
            output = model(feature)
            loss = F.cross_entropy(output, label)
            loss.backward()
            optimizer.step()
            avg_epoch_loss.append(loss.detach().numpy())
        print(f"Epoch {epoch+1}: {np.mean(avg_epoch_loss):.4f}")
    print("Training finished.")
    model.eval()
    X_tensor.requires_grad = True
    output = model(X_tensor)
    output_mean = output.mean()
    output_mean.backward()
    feature_importance = X_tensor.grad.abs().mean(dim=0).detach().numpy()
    importance_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': feature_importance
    }).sort_values('Importance', ascending=False)
    importance_df['Percentile'] = importance_df['Importance'].rank(pct=True)
    def significance_marker(pct):
        if pct >= 0.9:
            return '***'
        elif pct >= 0.75:
            return '**'
        elif pct >= 0.5:
            return '*'
        else:
            return ''
    importance_df['Significance'] = importance_df['Percentile'].apply(significance_marker)
    nonlinear_features = importance_df.loc[importance_df['Significance'] != '', 'Feature']
    nonlinear_features_set = list(nonlinear_features)

    return importance_df, nonlinear_features_set

def to_numpy(x):
    if isinstance(x, torch.Tensor):
        return x.detach().cpu().numpy()
    return np.array(x)

def analyze_lasso_significance(X, y, feature_names, alpha=0.01, random_state=42, max_iter=10000):
    lasso = Lasso(alpha=alpha, random_state=random_state, max_iter=max_iter)
    lasso.fit(to_numpy(X), to_numpy(y))
    lasso_features_set = [feature_names[i] for i, coef in enumerate(lasso.coef_) if coef != 0]

    return lasso.coef_, lasso_features_set


def optimize_feature_selection(adjustment_vars, instrumental_vars, confounder_vars, spurious_vars, data='codiet', seed=0):
    best_feature = None
    max_count = -1
    best_summary_df = None

    for feature in adjustment_vars:
        X, y, feature_names = load_data(data=data, target_feature=feature, seed=seed)
        if X is None or y is None:
            continue

        # Handle NaNs in y before discretization
        y_cleaned = y[~np.isnan(y)]
        X_cleaned = X[~np.isnan(y)]

        if len(y_cleaned) == 0:
            print(f"Warning: Target variable '{feature}' contains only NaNs. Skipping feature selection for this target.")
            continue

        # Discretize the target variable y using quantiles and map to 0-indexed labels
        # Use fewer bins if the number of unique values is less than 10
        n_bins = min(10, len(np.unique(y_cleaned)))
        if n_bins < 2:
             print(f"Warning: Target variable '{feature}' has less than 2 unique values after cleaning. Cannot perform classification for nonlinear analysis. Skipping nonlinear analysis for this feature.")
             y_discretized = None # Indicate that discretization failed
             nonlinear_features_set = [] # No nonlinear features selected
        else:
            y_discretized = pd.qcut(y_cleaned, q=n_bins, labels=False, duplicates='drop')
            y_factorized, unique_labels = pd.factorize(y_discretized)
            actual_num_classes = len(unique_labels)

            # Ensure X_cleaned matches the length of y_factorized after removing NaNs
            X_cleaned_nonlinear = X_cleaned[~np.isnan(y_discretized)]


            importance_df, nonlinear_features_set = analyze_nonlinear_significance(
                X=X_cleaned_nonlinear, # Pass cleaned X
                y=y_factorized, # Pass the factorized target
                feature_names=feature_names,
                num_classes=actual_num_classes, # Pass the actual number of classes
                epochs=20,
                batch_size=16,
                lr=1e-3,
                seed=seed
            )

        feature_count_df, linear_features_set, mean_contributions = analyze_linear_significance(
            X=X_cleaned, # Use cleaned X for linear analysis as well
            feature_names=feature_names,
            pho=0.1,
            seed=seed
        )

        # Use original y for LASSO, as it can handle continuous targets
        lasso_coef, lasso_features_set = analyze_lasso_significance(
            X=X_cleaned, # Use cleaned X for LASSO
            y=y_cleaned, # Use cleaned y for LASSO
            feature_names=feature_names,
            alpha=0.01
        )

        def classify_feature(f):
            if f in instrumental_vars:
                return "instrumental"
            elif f in confounder_vars:
                return "confounder"
            elif f in adjustment_vars:
                return "adjustment"
            elif f in spurious_vars:
                return "spurious"
            else:
                return "unknown"

        # Combine features from all methods, including when nonlinear analysis was skipped
        all_features = set(list(feature_names) + linear_features_set + lasso_features_set + (nonlinear_features_set if y_discretized is not None and n_bins >= 2 else []))

        summary_df = pd.DataFrame({'Feature': list(all_features)})
        summary_df['Linear'] = summary_df['Feature'].apply(lambda x: x in linear_features_set)
        summary_df['Nonlinear'] = summary_df['Feature'].apply(lambda x: x in nonlinear_features_set if y_discretized is not None and n_bins >= 2 else False)
        summary_df['LASSO'] = summary_df['Feature'].apply(lambda x: x in lasso_features_set)
        summary_df['Category'] = summary_df['Feature'].apply(classify_feature)
        summary_df['Total_Selected'] = summary_df[['Linear', 'Nonlinear', 'LASSO']].sum(axis=1)
        summary_df['AdjConf_SelectedBy2Plus'] = summary_df.apply(
            lambda row: (
                (row['Category'] in ['adjustment', 'confounder'] and row['Total_Selected'] >= 2)
                or
                (row['Category'] not in ['adjustment', 'confounder'] and row['Total_Selected'] <= 2)
            ),
            axis=1
        )

        count_selected = len(summary_df[summary_df['AdjConf_SelectedBy2Plus'] == True])
        print(f"Feature: {feature}, Count Selected: {count_selected}")
        if count_selected > max_count:
            max_count = count_selected
            best_feature = feature
            best_summary_df = summary_df.copy()

    print(f"\nBest feature: {best_feature}")
    print(f"Max AdjConf_SelectedBy2Plus: {max_count}")
    return best_feature, max_count, best_summary_df

def select_features(data="cleaned_data", seed=0, max_iter=20):
    prev_max_count = -1
    iteration = 0
    all_adjustment_vars = adjustment_vars.copy()
    converged = False
    instrumental_vars = [
       "PINCP", "SOW", "COW", "WKHP",
       "POR", "CIOR", "COR", "POBP", "DOBP"
    ]

    confounder_vars = [
       'CSM', 'SMK', "AGEP", "SEX", "MAR", "ETH", "RAC1P",
       "EDU", "EMP", "WGTC", "WGTCN",
       "BMI25", "OBES",
       "DIAB", "HYP", "HYPM", "DYS", "DYSM",
       "CVD", "CANC", "REN", "INF", "GAST",
       "ABX", "CHR", "MEDI", "ILL", "WHL",
       "FALL", "PAI", "OAH", "OLP", "STH","SITE"
    ]
    
    adjustment_vars = [
       'FPG', 'SWTPT', "BMI", "WGHT", "HGT", "WC", "WHR", "WHTR", "VFA",
       "TRI", "BP", "MED",
       "ACE", "DIU", "STA", "INS", "ORH", "ANT", "HOR", "ANTD", "SUP",
       "PREF", "SWBV", "SWTPT", "SLPWK", "SLPFD", "NAP", "SLPQ",
       "VIG", "MODT", "WKT", "PHY", "WALK", "SIT",
       "FRUTU", "VEG", "RED", "LEG", "FISH", "NUTS", "OLIV", "OLAM",
       "TBW","FFM","PBF","VFA","SMM","WC","WHR","WHTR","BAI",
       "ABSI","AC","ACAR","AE","AFLL","AFUL","AI","ALC","ALFT","AMC","ANAC","ANBL",
       "AOAC","APEN","B12","B6","BCAR","BCM","BCRY","BEAN","BEEF","BFA","BFLA","BFLL",
       "BFM","BFMC","BFRA","BFRL","BFTR","BIOT","BMC","BMR","BRAS","BURG","BUT","CABD",
       "CAL","CALOR","CARB","CCH","CCHE","CHEC","CHOL","CIS1","CIS3","CIS6","CL",
       "CLARM","CLTH","CNE","CONI","COPP","CRARM","CRTH","CTUN","DRFR","EC","ECLA",
       "ECLL","ECMB","ECRA","ECRL","ECTB","ECTLA","ECTLL","ECTR","ECTRT","ECTW","ECW",
       "ETAR","ETLR","FAT","FATI","FFMC","FFMI","FIBR","FJUI","FMI","FOL","FRUC","FRUT",
       "FSDR","FSFJ","FSFP","FSHN","FSSF","FSTB","FSUG","FSVP","GLUC","GMB","HAIR",
       "HFLN","HR","ICLA","ICLL","ICRA","ICRL","ICTR","ICW","IMS","INBS","INBT","IOD",
       "IRON","KCAL","KH50","KHLA","KHLL","KHRA","KHRL","KHTR","KJ","LACT","LAMB",
       "LARM","LFHF","LFLN","LLEG","MALT","MG","MHRT","MINR","MN","NIAC","NIQE","NIRN",
       "NIT","NMS","NUT","OFFL","OFIS","ORRM","OTCH","OTSU","OVEG","PANT","PE","PHGTP",
       "PHOS","PORK","POT","POUL","PROT","PRPL","PRRM","PSI","PWGTP","RARM","RETL",
       "RHT","RIBF","RLEG","RMSSD","RSON","SAUS","SDNN","SE","SFALL","SFAT","SFAUL",
       "SHEL","SLM","SMFR","SMI","SMWT","SOD","SRD","STCH","STIN","STRE","SUCR","SVR",
       "SVSZ","TBFF","TBLA","TBLL","TBRA","TBRL","TBTR","TBWT","TCAR","TFS","TGWT",
       "THIA","TNIT","TOMA","TP","TPLN","TPUR","TRFA","TRUN","TRYP","TSRD","TSUG",
       "VFL","VITA","VITC","VITD","VITE","VLFL","WATR","WCTR","WFIS","XCHT","YRG","ZN",
       'LEFT', 'RDYM','PRSZ','MEDIET'
    ]

    spurious_vars = [
       "SERIALNO", "PID", "VST", "VOLT",
       "MEAL", "FOOD", "NTBL", "FGRC",
       "CMPL", "RES", "LCID",
       "OMED", "ODIET"
    ]

    while not converged and iteration < max_iter:
        best_feature, max_count, best_summary_df = optimize_feature_selection(
            adjustment_vars=all_adjustment_vars,
            instrumental_vars=instrumental_vars,
            confounder_vars=confounder_vars,
            spurious_vars=spurious_vars,
            data=data,
            seed=seed
        )
        print(f"\nIteration {iteration+1} | Best feature: {best_feature} | Max AdjConf_SelectedBy2Plus: {max_count}")

        if max_count <= prev_max_count:
            converged = True
            print("Converged.")
        else:
            prev_max_count = max_count
            if best_feature not in all_adjustment_vars:
                all_adjustment_vars.append(best_feature)
            iteration += 1

    print("\nFinal Category Classification:")
    return  best_summary_df

def plot_feature_heatmap(seed=0):

    best_summary_df = select_features(
        data=cleaned_data,
        seed=0
    )
    
    final_df = best_summary_df['Feature','Category']
    '''
    final_df = pd.DataFrame({
        'Feature': feature_names,
        'Category': final_categories
    })'''

    adjustment_set = list(final_df[final_df['Category'] == 'adjustment']['Feature'])
    confounder_set = list(final_df[final_df['Category'] == 'confounder']['Feature'])
    instrumental_set = list(final_df[final_df['Category'] == 'instrumental']['Feature'])
    spurious_set = list(final_df[final_df['Category'] == 'spurious']['Feature'])

    print(f"Adjustment Set: {adjustment_set}")
    print(f"Confounder Set: {confounder_set}")
    print(f"Instrumental Set: {instrumental_set}")
    print(f"Spurious Set: {spurious_set}")

    #df = pd.read_csv(codiet_url, engine='python', sep=';', on_bad_lines='skip')

    y_features = instrumental_set + spurious_set
    x_features = adjustment_set + confounder_set

    valid_y = [f for f in y_features if f in df.columns and np.issubdtype(df[f].dtype, np.number)]
    valid_x = [f for f in x_features if f in df.columns and np.issubdtype(df[f].dtype, np.number)]

    if not valid_y or not valid_x:
        raise ValueError(f"No valid numeric columns found! Valid_y: {valid_y}, Valid_x: {valid_x}")

    print(f"✅ Using {len(valid_x)} X-features and {len(valid_y)} Y-features.")

    sub_df = df[valid_x + valid_y].copy()
    sub_df = sub_df.dropna(axis=0, how='any')
    sub_df = sub_df.loc[:, sub_df.std() > 0]

    corr_df = pd.DataFrame(index=valid_y, columns=valid_x, dtype=float)
    for y in valid_y:
        for x in valid_x:
            if x in sub_df.columns and y in sub_df.columns:
                corr_df.loc[y, x] = sub_df[[x, y]].corr().iloc[0, 1]
            else:
                corr_df.loc[y, x] = np.nan
    corr_df = corr_df.fillna(0)

    fig_w = max(12, len(valid_x) * 0.8)
    fig_h = max(6, len(valid_y) * 0.8)
    plt.figure(figsize=(fig_w, fig_h))
    cg = sns.clustermap(
        corr_df,
        annot=False,
        cmap='coolwarm',
        vmin=-1, vmax=1,
        cbar=False,
        linewidths=0,
        linecolor=None,
    )
    cg.ax_heatmap.set_xlabel("Want (Adjustment & Confounder) Features", fontsize=12)
    cg.ax_heatmap.set_ylabel("Remove (Instrumental & Spurious) Features", fontsize=12)
    cg.ax_heatmap.set_title("Correlation Clustermap", fontsize=14, pad=20)
    plt.xticks([])
    plt.yticks([])
    plt.tight_layout()
   
    cg.savefig(correlation_heatmap)
    
    plt.show()
    

    


