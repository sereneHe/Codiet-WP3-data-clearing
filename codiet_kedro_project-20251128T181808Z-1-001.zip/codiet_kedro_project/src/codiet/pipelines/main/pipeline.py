from kedro.pipeline import Pipeline, node
from codiet.pipelines.main import data_cleaning_nodes, feature_selection

def create_pipeline(**kwargs):
    return Pipeline([
        node(
            func=data_cleaning_nodes.clean_data,
            inputs=["sociodemographics_data", "exdbn_data", "abbreviation_data"],
            outputs=["cleaned_data","data_dictionary"],
            name="clean_data_node"
        ),
        node(
            func=feature_selection.select_features,
            inputs="cleaned_data",
            outputs="summary_df",
            name="feature_selection_node"
        ),
        node(
            func=feature_selection.plot_feature_heatmap,
            inputs=None,
            outputs="correlation_heatmap",
            name="plot_heatmap"
        )
    ])